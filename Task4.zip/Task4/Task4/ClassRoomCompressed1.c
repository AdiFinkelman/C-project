#define  _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Teacher.h"
#include "Student.h"
#include "ClassRoom.h"
#include "utils.h"



void SetCompressionFormat(struct ClassRoom* pRoom) {}

void DeCompressClasses(struct ClassRoom *pRooms) {}

void CompressClasses(struct ClassRoom* pRooms) {}