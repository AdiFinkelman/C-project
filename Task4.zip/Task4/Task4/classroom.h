#ifndef __CLASSROOM_H__
#define __CLASSROOM_H__
#define  _CRT_SECURE_NO_WARNINGS

#define NUM_OF_CLASSROOMS 3
#define MAX_CLASS_CAPAVITY 30
#define MAX_CLASS_NAME_LEN	32
#define NUM_OF_TEACHERS 6
#define NUM_OF_TEACHERS_PER_STUDENT 3
#define NUM_OF_STUDENTS	64
#define INVALID_ROOM_ID (unsigned char)0xFF
#define MAX_TEACHER_NAME_LEN 20
#define MAX_STUDENT_NAME_LEN 11
#define NZ_BIT 0b1

#define STUDENT_ID_MASK 0b111111 
#define STUDENT_ID_SHIFT 10
#define COMPRESSION_FORMAT_UPPER_CASE_ONLY 0b01
#define COMPRESSION_FORMAT_LOWER_CASE_ONLY 0b10
#define COMPRESSION_FORMAT_ALPHA_ALL (COMPRESSION_FORMAT_LOWER_CASE_ONLY | COMPRESSION_FORMAT_UPPER_CASE_ONLY)
#define MY_COMPRESSION_FORMAT_NONE	0b00
#define TYPE_CLASSROOM	1
#define TYPE_TEACHER 2
#define TYPE_STUDENT 3

#define DATA_COMPRESSED_FILE "data_compress.bin"

struct Student;
struct Teacher;

struct ClassRoom {
	char* name;
	int index;
	unsigned short  max_capacity;
	unsigned short cur_capacity;
	unsigned char compressionFormat;
	unsigned char real_len;
	struct Teacher* teacher; // The current teacher using this class
	struct Student** students; // Array of students assinged to this class and teacher
	int (*Compress)(struct ClassRoom*, FILE *);
};

struct ClassRoom* GenerateClassRooms(void);
void PrintRooms(struct ClassRoom* rooms);
void PrintRoom(struct ClassRoom* room);
void AssignTeacherToClass(struct ClassRoom* pRoom, struct Teacher* pTeacher, struct Student* pStudents);
void ReleaseClass(struct ClassRoom* pRoom);
struct ClassRoom* FindAvailableClass(struct ClassRoom* pRooms);
struct ClassRoom* FindClassByName(char* class_name, struct ClassRoom* pRooms);
struct ClassRoom* FindClassByIndex(unsigned char RoomId, struct ClassRoom* pRooms);
signed char GetClassIndex(unsigned short nameLen, struct ClassRoom* pRoom, struct ClassRoom* pRooms);
void RenameClass(struct ClassRoom* pRooms);

int SimpleCompress(struct ClassRoom* pRoom, FILE* fp);
int SimpleDeCompress(struct ClassRoom* pRoom, FILE* fp);
void DeCompressClasses(struct ClassRoom* pRooms);
void CompressClasses(struct ClassRoom* pRooms);
int CompressClassRoomHeader(struct ClassRoom* pRoom, int compressed_len, FILE* fp);
int DecompressClassRoom(struct ClassRoom* pRoom, FILE* fp);
void SetCompressionFormat(struct ClassRoom* pRoom);

#endif
