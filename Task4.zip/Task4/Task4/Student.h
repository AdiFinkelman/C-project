#ifndef __STUDENT_H__
#define __STUDENT_H__

#define  _CRT_SECURE_NO_WARNINGS

#include "ClassRoom.h"
#include "Teacher.h"



struct Teacher;
struct ClassRoom;

struct Student {
	struct ClassRoom* curClass; // Current class room
	struct Teacher* teachers[NUM_OF_TEACHERS_PER_STUDENT]; // Vector of possible teachers
	char* name;
};

int AssignTeachersToStudent(struct Student* student, struct Teacher* teachers);
void PrintStudents(struct Student* st, int len);
int GenerateStudents(struct Student** students, int num);
int IsStudentTeacher(struct Student* student, struct Teacher* teacher);

#endif
