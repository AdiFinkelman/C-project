
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>


#include "ClassRoom.h"
#include "Teacher.h"
#include "Student.h"
#include "utils.h"
#include "file.h"


void Help()
{
	puts("\n\nH/h - for help");
	puts("P/p - Print all class rooms");
	puts("S/s - Print all students");
	puts("T/t - Print all teachers");
	puts("C/c - Assign class to a teacher");
	puts("W/w - Write to file");
	puts("Z/z - Compress a class to data_enc.bin");
	puts("Y/y - DeCompress a class from data_enc.bin");
	puts("L/l - load data from file");
	puts("E/e - rename a room");
	puts("R/r - Release class room");
	puts("Q/q - Quit\n\n");
}

void assignTeachers(struct Student* pStudents, struct Teacher* pTeachers)
{
	for (int i = 0; i < NUM_OF_STUDENTS; i++) {
		AssignTeachersToStudent(pStudents + i, pTeachers);
	}
}

void CreateClass(struct ClassRoom* pRooms, struct Teacher* pTeachers, struct Student* pStudents)
{
	if (!pRooms) {
		printf("Please load data file\n");
		return;
	}
	struct ClassRoom* pRoom = FindAvailableClass(pRooms);
	if (!pRoom) {
		printf("No available room, release a room first\n");
		return;
	}
	printf("Found an available room %s\n", pRoom->name);
	printf("Please choose a teacher by name out of this list:");
	PrintTeachersList(pTeachers);

	char chosen_name[254] = { 0 };
	do {
		fflush(stdout);
		fgets(chosen_name, sizeof(chosen_name), stdin);
	} while (!isalpha(chosen_name[0]));

	StripToAlpha(chosen_name);
	
	struct Teacher* pTeacher;
	pTeacher = FindTeacher(chosen_name, pTeachers);
	if (!pTeacher) {
		printf("Failed to find %s\n", chosen_name);
		return;
	}
	if (pTeacher->classroom != NULL) {
	
		printf("Error: Teacher %s teaches in room %s\n", 
			pTeacher->name, pTeacher->classroom->name);
		return;
	}
	AssignTeacherToClass(pRoom, pTeacher, pStudents);
}

void ReleaseTheClass(struct ClassRoom* pRooms)
{
	char chosen_name[254] = { 0 };
	
	if (!pRooms) {
		printf("No rooms available\n");
		return;
	}

	printf("Please enter Class name to rlease\n");
	fflush(stdout);
	fflush(stdin);
	
	do {
		fgets(chosen_name, sizeof(chosen_name), stdin);
	} while (!isalpha(chosen_name[0]));

	StripToAlpha(chosen_name);


	struct ClassRoom *pRoom = FindClassByName(chosen_name, pRooms);
	if (!pRoom) {
		printf("Invalid class rooom\n");
		return;
	}
	if (pRoom->cur_capacity == 0) {
		printf("Error: room is not assigned\n");
		return;
	}
	ReleaseClass(pRoom);
}

void LoadData(struct ClassRoom** ppRooms,
	struct Teacher** ppTeachers,
	struct Student** ppStudents)

{
	if (*ppRooms)
		free(*ppRooms);
	if (*ppTeachers)
		free(*ppTeachers);
	if (*ppStudents)
		free(*ppStudents);
	ReadBinFile(DATA_FILE, ppRooms, ppTeachers, ppStudents);
}

int main()
{
	struct ClassRoom* pRooms = NULL, **ppRooms = &pRooms;
	struct Student* pStudents = NULL;
	struct Student** ppStudents = &pStudents;
	struct Teacher* pTeachers = NULL, **ppTeachers = &pTeachers;

	unsigned short n = 0x000b;
	unsigned char n1 = ((unsigned char *)&n)[1];

	// Phase 3. 
	do {
		fflush(stdin);
		Help();
		
		char opt;
		do {
			opt = getchar();
		} while (opt == 10);

		switch (opt)
		{

		case 'p':
		case 'P':
			PrintRooms(pRooms);
			break;
		
		case 'T':
		case 't':
			PrintTeachers(pTeachers);
			break;

		case 's':
		case 'S':
			PrintStudents(pStudents, NUM_OF_STUDENTS);
			break;

		case 'c':
		case 'C':
			CreateClass(pRooms, pTeachers, pStudents);
			break;

		case 'r':
		case 'R':
			ReleaseTheClass(pRooms);
			break;
		
		case 'E':
		case 'e':
			RenameClass(pRooms);
			break;
		case 'w':
		case 'W':
			WriteBinFile("data.bin", pStudents,
				NUM_OF_STUDENTS,
				pTeachers, NUM_OF_TEACHERS,
				pRooms, NUM_OF_CLASSROOMS);
			break;
		
		case 'l':
		case 'L':
			LoadData(ppRooms, ppTeachers, ppStudents);
			break;
		
		case 'q':
		case 'Q':
			exit(0);
		
		case 'Z':
		case 'z':
			CompressClasses(pRooms);
			break;
		
		case 'Y':
		case 'y':
			DeCompressClasses(pRooms);
			break;

		case 'h':
		case 'H':
			Help();
			break;

		}
	} while (1);
}


