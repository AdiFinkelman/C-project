#define  _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>


#include "ClassRoom.h"
#include "Teacher.h"
#include "Student.h"
#include "utils.h"
#include "file.h"

void SetCompressionFormat(struct ClassRoom* pRoom)
{
	char* str = pRoom->name;
	size_t len = strlen(pRoom->name);
	int lower_case = 0;
	int upper_case = 0;
	int special_chars = 0;

	for (int i = 0; i < len; i++) {
		if (str[i] >= 'a' && str[i] <= 'z') {
			lower_case++;
			continue;
		}
		if (str[i] >= 'A' && str[i] <= 'Z') {
			lower_case++;
			continue;
		}
		special_chars++;
	}

	if (special_chars > 0) {
		return;
	}

	pRoom->Compress = SimpleCompress;
	// No special chars, only alphabet
	if (lower_case > 0 && upper_case > 0) {
		pRoom->compressionFormat = COMPRESSION_FORMAT_ALPHA_ALL;
		return;
	}

	if (lower_case == len) {
		pRoom->compressionFormat = COMPRESSION_FORMAT_LOWER_CASE_ONLY;
		return;
	}
	if (upper_case == len) {
		pRoom->compressionFormat = COMPRESSION_FORMAT_UPPER_CASE_ONLY;
		return;
	}
	pRoom->Compress = NULL;
	printf("Value cannot be compressed\n");
}



int DecompressClassRoomHeader(struct ClassRoom* pRoom, FILE *fp)
{
	unsigned short header = 0;;
	unsigned char index;
	unsigned char compression_format ;
	unsigned char max_capacity;
	unsigned char name_len;

	size_t rc = fread(&header, sizeof(header), 1, fp);
	if (rc != 1) {
		printf("%s Failed to read header\n", __FUNCTION__);
		return -1;
	}
	header = HTONS(header);
	index = (header & 0xC000) >> (6+6+2);
	compression_format = (header & 0x3000)>> 12;
	max_capacity = (header & 0b111111000000) >> 6;
	name_len = header & 0b111111;
	// some sanity checks
	if (index > 3) {
		printf("%s Insane class room index\n", __FUNCTION__);
		return -1;
	}
	pRoom->index = index;
	pRoom->max_capacity = max_capacity;
	pRoom->real_len = name_len;
	return 0;
}

int CompressClassRoomHeader(struct ClassRoom* pRoom, unsigned char len, FILE* fp)
{
	unsigned short header = 0;
	unsigned char index = pRoom->index;
	unsigned char max_capacity = (unsigned char)pRoom->max_capacity;

	header = index << (2 + 6 + 6);
	header = header | (pRoom->compressionFormat << (6 + 6));
	header = header | (max_capacity << 6);
	header = header | len & 0b111111; 
	header = HTONS(header);

	size_t rc = fwrite(&header, sizeof(header), 1, fp);
	if (rc != 1) {
		printf("%s Failed to write header\n", __FUNCTION__);
		return -1;
	}

	return 0;
}

void CompressClasses(struct ClassRoom* pRooms)
{
	if (pRooms == NULL) {
		printf("Please load %s first\n", DATA_FILE);
		return;
	}

	for (int i = 0; i < NUM_OF_CLASSROOMS; i++) {
		struct ClassRoom* pRoom = &pRooms[i];
		if (pRoom->compressionFormat == MY_COMPRESSION_FORMAT_NONE){
			printf("Class %s is not available for compression\n", 
				pRoom->name);
			return;
		}
	}
	FILE* fp = fopen(DATA_COMPRESSED_FILE, "wb");
	if (fp == NULL) {
		perror("Failed to open compressed file");
		return;
	}

	for (int i = 0; i < NUM_OF_CLASSROOMS; i++) {
		struct ClassRoom* pRoom = &pRooms[i];
		pRoom->Compress(pRoom, fp);
	}
	fclose(fp);
}


int SimpleCompress(struct ClassRoom* pRoom, FILE* fp)
{
	int compressed_len;
	
	unsigned char  temp_compressed_vals[64];
	unsigned char  compressed_vals[64];
	
	// Create an array of values no bigger than 64
	// 'z' = 122, 'A' = 65, therefore, 'z' -'A' = 57 < 2^6 = 64.
	size_t len = strlen(pRoom->name);
	for (int i = 0; i < len; i++) {
		// Convert to use only 6 lsb bits
		temp_compressed_vals[i] = pRoom->name[i] - 'A';
	}
	//
	// carefull here. 
	// 7 char --> 7*6 = 42 bits
	// 42/8 > 5 --> 6 bytes 
	// when reading we need to find the exact compressed size, so: 
	// thus, we read 7 --> 7 * 6 = 42 --> ceil(42/8)= 6
	float cells = (float)0.75 * (float)len;
	compressed_len = (int)ceil(cells) ;

	// 4 bytes to 3 bytes compression proportion
	int j = 0;
	for (int i = 0; i < len; i+=4,j+=3) {
		// We only grab 6 lsb from each temporary compressed character
		// then we put it in the compressed byte array
		compressed_vals[j]      =  (temp_compressed_vals[i + 0]  & 0b00111111) << 2; //1 
		compressed_vals[j]     |=  (temp_compressed_vals[i + 1]  & 0b00110000) >> 4; //2
		
		compressed_vals[j + 1]  =  (temp_compressed_vals[i + 1]  & 0b00001111) << 4; //2
		compressed_vals[j + 1] |= ((temp_compressed_vals[i + 2]  & 0b00111100) >> 2); //3

		compressed_vals[j + 2]  = ((temp_compressed_vals[i + 2]  & 0b00000011) << 6); //3
		compressed_vals[j + 2] |= ((temp_compressed_vals[i + 3]  & 0b00111111)); //4
	}

	
	CompressClassRoomHeader(pRoom, len, fp);
	// should compress the ascii
	size_t rc = fwrite(&compressed_vals, compressed_len, 1, fp);
	if (rc != 1) {
		printf("%s Failed to write header\n", __FUNCTION__);
		return -1;
	}
	return 0;
}

int SimpleDeCompress(struct ClassRoom* pRoom, FILE* fp)
{
	unsigned char compressed_vals[64];
	unsigned char temp_decompressed_vals[64]; // maximum size possible + 1
	int compressed_bytes;

	compressed_bytes = ceil(pRoom->real_len * 0.75);
	size_t rc = fread(&compressed_vals, compressed_bytes, 1, fp);
	if (rc != 1) {
		printf("%s Failed to read name\n", __FUNCTION__);
		return -1;
	}

	// Create an array of values no bigger than 64
	// 'z' = 122, 'A' = 65, therefore, z-A=57 < 2^6=64. 
	
	int j = 0;
	int i = 0;
	for (; j < pRoom->real_len; i += 4,j+=3) {
		temp_decompressed_vals[i + 0] = (compressed_vals[j] &  0b11111100) >> 2;
		temp_decompressed_vals[i + 1] = ((compressed_vals[j] & 0b00000011) << 4)|  ((compressed_vals[j + 1] & 0b11110000) >> 4);
		temp_decompressed_vals[i + 2] = ((compressed_vals[j + 1] & 0b00001111) << 2) | ((compressed_vals[j + 2] & 0b11000000) >> 6);
		temp_decompressed_vals[i + 3] = (compressed_vals[j + 2] & 0b111111);
	}
	//
	//	7 real len
	//	
	size_t len = pRoom->real_len;
	pRoom->name = calloc(len + 1, 1);
	if (!pRoom->name) {
		printf("%s Failed to allocate", pRoom->name);
		return -1;
	}

	for (int i = 0; i < len; i++) {
		pRoom->name[i] = 'A' + temp_decompressed_vals[i];
		
	}
	return 0;
}

void DeCompressClasses(struct ClassRoom *pRooms)
{
	if (pRooms == NULL) {
		printf("Please load %s first\n", DATA_FILE);
		return;
	}

	FILE* fp = fopen(DATA_COMPRESSED_FILE, "rb");
	if (fp == NULL) {
		perror("Failed to open compressed file");
		return;
	}

	for (int i = 0; i < NUM_OF_CLASSROOMS; i++) {
		struct ClassRoom* pRoom = &pRooms[i];
		DecompressClassRoomHeader(pRoom, fp);
		SimpleDeCompress(pRoom, fp);
	}
	fclose(fp);
}