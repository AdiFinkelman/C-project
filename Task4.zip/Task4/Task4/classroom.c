#define  _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Teacher.h"
#include "Student.h"
#include "ClassRoom.h"
#include "utils.h"


void PrintRoom(struct ClassRoom* room)
{
	puts("\n*************************");
	printf("\nClass Name %s\n", room->name);
	printf("Current Capacity %d\n", room->cur_capacity);
	printf("Max Capacity %d\n", room->max_capacity);
	PrintTeacher(room->teacher);

	long** array = (long **)room->students;
	for (int i = 0; i < room->cur_capacity; i++) {
		struct Student* student = room->students[i];
		printf("%s ", student->name);
	}
}


void PrintRooms(struct ClassRoom* pRooms)
{
	struct ClassRoom* room = pRooms;
	if (!room) {
		printf("No Rooms\n");
		return;
	}

	for (int i = 0; i < NUM_OF_CLASSROOMS; i++, room++) {
		PrintRoom(room);
	}
}


struct ClassRoom* GenerateClassRooms(void)
{
	int i;
	char className[MAX_CLASS_NAME_LEN];

	struct ClassRoom* classRooms = malloc(sizeof(struct ClassRoom) * NUM_OF_CLASSROOMS);
	if (!classRooms) {
		return NULL;
	}

	struct ClassRoom* room = classRooms;

	for (i = 0; i < NUM_OF_CLASSROOMS; i++, room++) {
		room->max_capacity = (rand() % (MAX_CLASS_CAPAVITY - 9)) + 10;
		room->cur_capacity = 0;
		room->compressionFormat = MY_COMPRESSION_FORMAT_NONE;
		room->teacher = NULL;
		printf("Enter class name:");
		char *s = fgets(className, MAX_CLASS_NAME_LEN - 1, stdin);
		StripToAlpha(s);
		room->name = malloc(strlen(s) + 1);
		if (!room->name) {
			return NULL;
		}
		strcpy(room->name, s);
		fflush(stdin);

	}

	return classRooms;
}

void AssignTeacherToClass(struct ClassRoom* pRoom, struct Teacher* pTeacher, struct Student* pStudents)
{
	pRoom->teacher = pTeacher;
	struct Student* pStudent = pStudents;

	pRoom->students = (struct Student **)calloc(pRoom->max_capacity, sizeof(struct Student*));
	if (!pRoom->students) {
		printf("Error: Failed to allocate students pointer array\n");
		return;
	}

	for (int i = 0; i < NUM_OF_STUDENTS; i++) {
		if (IsStudentTeacher(pStudent, pTeacher)) {
			pRoom->students[pRoom->cur_capacity] = pStudent;
			pRoom->cur_capacity++;
			pStudent->curClass = pRoom;
			if (pRoom->cur_capacity == pRoom->max_capacity) {
				break;
			}
		}
		pStudent++;
	}
	pTeacher->classroom = pRoom;
	PrintRoom(pRoom);
}

struct ClassRoom* FindAvailableClass(struct ClassRoom* pRooms)
{
	struct ClassRoom* pRoom = pRooms;

	for (int i = 0; i < NUM_OF_CLASSROOMS; i++) {
		if (pRoom->cur_capacity == 0)
			return pRoom;
		pRoom++;
	}
	return NULL;
}

struct ClassRoom* FindClassByName(char *class_name, struct ClassRoom* pRooms)
{
	struct ClassRoom* pRoom = pRooms;

	for (int i = 0; i < NUM_OF_CLASSROOMS; i++) {
		if (!strcmp(pRoom->name, class_name))
			return pRoom;
		pRoom++;
	}
	return NULL;
}

struct ClassRoom* FindClassByIndex(unsigned char RoomId, struct ClassRoom* pRooms)
{
	return &pRooms[RoomId];
}

signed char GetClassIndex(unsigned short nameLen, struct ClassRoom* pRoom, struct ClassRoom* pRooms)
{
	for (int i = 0; i < NUM_OF_CLASSROOMS; i++) {
		struct ClassRoom* pCurRoom = &pRooms[i];
		if (!strncmp(pRoom->name, pCurRoom->name, nameLen))
			return (signed char)i;
	}
	return (signed char)(-1);
}

void ReleaseClass(struct ClassRoom* pRoom)
{
	if (pRoom->cur_capacity == 0)
		return;
	free(pRoom->students);
	pRoom->teacher->classroom = NULL;
	pRoom->teacher = NULL;
	pRoom->cur_capacity = 0;
	free(pRoom->name);
}


void RenameClass(struct ClassRoom* pRooms)
{
	printf("Enter the current room name\n");
	char class_name[254] = { 0 };
	GetString(class_name, sizeof(class_name));

	struct ClassRoom *pRoom = FindClassByName(class_name, pRooms);
	if (!pRoom) {
		printf("Failed to find room %s\n", class_name);
		return;
	}
	printf("Enter the the new room name\n");
	memset(class_name, 0x00, sizeof(class_name));
	GetString(class_name, sizeof(class_name));
	free(pRoom->name);
	size_t len = strlen(class_name) + 1;
	pRoom->name = malloc(len);
	if (!pRoom->name) {
		printf("Failed to allocat memory\n");
		return;
	}
	memset(pRoom->name, 0x00, len);
	strcpy(pRoom->name, class_name);
	SetCompressionFormat(pRoom);
	printf("Successfully renamed class\n");
}

