

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>


void StripToAlpha(char* s)
{
	size_t l = strlen(s);
	if (!isalpha(s[l - 1]))
		s[l - 1] = 0;
}

void GetString(char* str, int len)
{
	do {
		fflush(stdout);
		fgets(str, len, stdin);
	} while (!isalpha(str[0]));

	StripToAlpha(str);
}
