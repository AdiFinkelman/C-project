#define  _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Student.h"


void PrintStudents(struct Student *st, int len)
{
	if (!st) {
		printf("No students\n");
		return;
	}
	for (int i = 0; i < len; i++) {
		printf("\n%s ", st->name);

		if (st->teachers[0]) {
			printf("Teachers :");
			for (int j = 0; j < NUM_OF_TEACHERS_PER_STUDENT; j++) {
				if (st->teachers[j])
					printf("\t %s\n", st->teachers[j]->name);
			}
		}
		st++;
	}
}


int IsStudentTeacher(struct Student* student, struct Teacher* teacher)
{
	for (int i = 0; i < NUM_OF_TEACHERS_PER_STUDENT; i++) {
		if (student->teachers[i] != NULL) {
			if (student->teachers[i] == teacher)
				return 1;
		}
	}
	return 0;
}

// Randonly choose teachers to a student
int AssignTeachersToStudent(struct Student* student, struct Teacher* teachers)
{
	struct Teacher* teacher;

	for (int i = 0; i < NUM_OF_TEACHERS_PER_STUDENT; i++) {
		do {
			int idx = rand() % NUM_OF_TEACHERS;
			const char* teacher_name = GetTeacherNameByIdx(idx);
			teacher = FindTeacher(teacher_name, teachers);
		} while (IsStudentTeacher(student, teacher));

		student->teachers[i] = teacher;
	}

	return 0;
}

int GenerateStudents(struct Student** students, int num)
{
	char student_name[16] = { 0 };
	*students = malloc(sizeof(struct Student) * num);

	if (!(*students)) {
		return -1;
	}

	struct Student* student = *students;
	for (int i = 0; i < num; i++) {
		sprintf(student_name, "student_%d", 100 + i);
		student->curClass = NULL;
		student->name = malloc(strlen(student_name) + 1);
		if (!student->name) {
			return -1;
		}

		strcpy(student->name, student_name);

		// Initialize teachers array
		for (int j = 0; j < NUM_OF_TEACHERS_PER_STUDENT; j++) {
			student->teachers[j] = NULL;
		}
		student++;
	}

	return 0;
}