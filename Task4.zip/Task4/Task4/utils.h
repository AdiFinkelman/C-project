#ifndef __UTILS_H__
#define __UTILS_H__

void StripToAlpha(char* s);
void GetString(char* str,int len);

#endif

