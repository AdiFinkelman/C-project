
#ifndef __TEACHER_H__
#define __TEACHER_H__
#define  _CRT_SECURE_NO_WARNINGS

struct Student;
struct ClassRoom;

struct Teacher {
	char* name;
	struct ClassRoom* classroom;
};

struct Teacher* FindTeacher(const char* name, struct Teacher* teachers);
const char* GetTeacherNameByIdx(int idx);
void PrintTeacher(struct Teacher*);
struct Teacher* GenerateTeachers(void);
void PrintTeachers(struct Teacher* teachers);
void PrintTeachersList(struct Teacher*  pTeachers);
struct Teacher* FindTeacherFromIndex(unsigned char idx, struct Teacher** ppTeacehrs);
unsigned char GetIndexOfTeacher(struct Teacher* pTeacher, struct Teacher* pTeachers);
struct Teacher* GetTeacherByIndex(signed char idx, struct Teacher* pTeachers);

#endif
