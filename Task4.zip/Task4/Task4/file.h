
#ifndef __FILE_H__
#define __FILE_H__

void WriteBinFile(
	const char* filename,
	struct Student* ppStudents,
	int NumStudents,
	struct Teacher* ppTeachers,
	int NumTeachers,
	struct ClassRoom* ppRooms,
	int NumClassRooms);

void ReadBinFile(const char* fileName,
	struct ClassRoom** ppRooms,
	struct Teacher** ppTeachers,
	struct Student** ppStudents);

#define DATA_FILE "data.bin"
#define HTONS(n) (((((unsigned short)(n) & 0xFF)) << 8) | (((unsigned short)(n) & 0xFF00) >> 8))


#endif

