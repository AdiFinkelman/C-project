#define  _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <errno.h>

#include "ClassRoom.h"
#include "Teacher.h"
#include "Student.h"
#include "utils.h"
#include "file.h"

int WriteClassRooms(struct ClassRoom* pRooms, int NumClassRooms, FILE* fp)
{
	size_t rc;
	unsigned char type = TYPE_CLASSROOM;
	
	rc = fwrite(&type, sizeof(type), 1, fp);
	if (rc != 1) {
		printf("Failed to write type (%s)\n",
			strerror(errno));
		return -1;
	}

	unsigned short records = (unsigned short)NumClassRooms;
	rc = fwrite(&records, sizeof(records), 1, fp);
	if (rc != 1) {
		printf("Failed to write number of records (%s)\n",
			strerror(errno));
		return -1;
	}

	for (int i = 0; i < records; i++) {
		
		unsigned char roomIdx = i;
		struct ClassRoom* pRoom = &pRooms[i];

		rc = fwrite(&roomIdx, sizeof(roomIdx), 1, fp);
		if (rc != 1) {
			printf("Failed to write room index (%s)\n",
				strerror(errno));
			return -1;
		}

		unsigned short nameLen = (unsigned short )strlen(pRoom->name);
		rc = fwrite(&nameLen, sizeof(nameLen), 1, fp);
		if (rc != 1) {
			printf("Failed to write room name len (%s)\n",
				strerror(errno));
			return -1;
		}

		rc = fwrite(pRoom->name ,(size_t)nameLen, 1, fp);
		if (rc != 1) {
			printf("Failed to write room name (%s)\n",
				strerror(errno));
			return -1;
		}

		rc = fwrite(&pRoom->max_capacity, sizeof(pRoom->max_capacity), 1, fp);
		if (rc != 1) {
			printf("Failed to write room's maximum capacity (%s)\n",
				strerror(errno));
			return -1;
		}
	}

	return 0;
}


int WriteTeachers(struct Teacher *pTeachers, struct ClassRoom *pRooms, int NumTeachers, FILE *fp)
{
	size_t rc;
	unsigned char type = TYPE_TEACHER;

	rc = fwrite(&type, sizeof(type), 1, fp);
	if (rc != 1) {
		printf("Failed to write teacher type (%s)\n",
			strerror(errno));
		return -1;
	}

	unsigned short records = (unsigned short)NumTeachers;
	rc = fwrite(&records, sizeof(records), 1, fp);
	if (rc != 1) {
		printf("Failed to write number of teachers (%s)\n",
			strerror(errno));
		return -1;
	}

	for (int i = 0; i < NumTeachers; i++) {

		struct Teacher* pTeacher = &pTeachers[i];
		unsigned short nameLen = (unsigned short)strlen(pTeacher->name);

		rc = fwrite(&nameLen, sizeof(nameLen), 1, fp);
		if (rc != 1) {
			printf("Failed to write teacher name len (%s)\n",
				strerror(errno));
			return -1;
		}

		rc = fwrite(pTeacher->name, nameLen, 1, fp);
		if (rc != 1) {
			printf("Failed to write teacher name (%s)\n",
				strerror(errno));
			return -1;
		}
	}
	return 0;
}

int WriteStudents(struct Student* pStudents, struct Teacher *pTeachers, struct ClassRoom *pRooms, int NumStudents, FILE* fp)
{
	size_t rc;
	unsigned char type = TYPE_STUDENT;

	rc = fwrite(&type, sizeof(type), 1, fp);
	if (rc != 1) {
		printf("Failed to write teacher type (%s)\n",
			strerror(errno));
		return -1;
	}

	unsigned short records = (unsigned short)NumStudents;
	rc = fwrite(&records, sizeof(records), 1, fp);
	if (rc != 1) {
		printf("Failed to write number of teachers (%s)\n",
			strerror(errno));
		return -1;
	}

	for (int i = 0; i < NumStudents; i++) {

		struct Student* pStudent = &pStudents[i];
		unsigned short nameLen = (unsigned short) strlen(pStudent->name);

		rc = fwrite(&nameLen, sizeof(nameLen), 1, fp);
		if (rc != 1) {
			printf("Failed to write student name len (%s)\n",
				strerror(errno));
			return -1;
		}

		rc = fwrite(pStudent->name, nameLen, 1, fp);
		if (rc != 1) {
			printf("Failed to write student's name(%s)\n",
				strerror(errno));
			return -1;
		}

		signed char teachers[NUM_OF_TEACHERS_PER_STUDENT] = { 0 };

		for (int j = 0; j < NUM_OF_TEACHERS_PER_STUDENT; j++) {
			teachers[j] = GetIndexOfTeacher(pStudent->teachers[j], pTeachers);
			if (teachers[j] < 0) {
				printf("Failed to get teachers's index \n");
				return -1;
			}
		}

		rc = fwrite(&teachers, sizeof(teachers), 1, fp);
		if (rc != 1) {
			printf("Failed to write student's teacher indexes(%s)\n",
				strerror(errno));
			return -1;
		}

	}

	return 0;
}

/*
* Write the data file in the requested formation.
*/
void WriteBinFile(
	const char* filename,
	struct Student *ppStudents,
	int NumStudents,
	struct Teacher* ppTeachers,
	int NumTeachers,
	struct ClassRoom* ppRooms,
	int NumClassRooms)
{
	FILE* fp;

	fp = fopen(filename, "w");
	if (!fp) {
		printf("Failed to open %s err=(%s)", 
			filename, 
			strerror(errno));
		return;
	}
	
	if (WriteClassRooms(ppRooms, NumClassRooms, fp)) {
		printf("failed to write classrooms\n");
		fclose(fp);
		return;
	}

	if (WriteTeachers(ppTeachers, ppRooms, NumTeachers, fp)) {
		printf("failed to write teacehrs\n");
		fclose(fp);
		return;
	}

	if (WriteStudents(ppStudents, ppTeachers, ppRooms, NumStudents, fp)) {
		printf("failed to write students\n");
		fclose(fp);
		return;
	}

	fclose(fp);
	printf("Successfully wrote data file\n");
}

int ReadTeachers(FILE* fp, int records, struct Teacher* pTeachers, struct ClassRoom* pRooms)
{
	unsigned short nameLen;
	struct Teacher* pTeacher;

	for (int i = 0; i < records; i++) {

	    pTeacher = &pTeachers[i];
		size_t rc = fread(&nameLen, sizeof(nameLen), 1, fp);
		if (rc != 1) {
			printf("Failed to read student name len(%s)\n",
				strerror(errno));
			return -1;
		}
		pTeacher->name = malloc(nameLen + 1);
		if (!pTeacher->name) {
			return -1;
		}
		memset(pTeacher->name, 0x00, nameLen + 1);
		rc = fread(pTeacher->name, nameLen,1, fp);
		if (rc != 1) {
			printf("Failed to read the qteacher name (%s)\n",
				strerror(errno));
			return -1;
		}
	}
	return 0;
}

int ReadStudents(FILE *fp, int records, 
	struct ClassRoom* pRooms,
	struct Teacher* pTeachers,
	struct Student* pStudents)
{
	unsigned short nameLen;

	for (int i = 0; i < records; i++) {
		
		struct Student* pStudent = &pStudents[i];

		size_t rc = fread(&nameLen, sizeof(nameLen), 1, fp);
		if (rc != 1) {
			printf("Failed to read student name len(%s)\n",
				strerror(errno));
			return -1;
		}
		pStudent->name = malloc(nameLen + 1);
		if (!pStudent->name) {
			return -1;
		}
		memset(pStudent->name, 0x00, nameLen + 1);
		rc = fread(pStudent->name, nameLen,1, fp);
		if (rc != 1) {
			printf("Failed to read class name (%s)\n",
				strerror(errno));
			return -1;
		}

		signed char teachers[NUM_OF_TEACHERS_PER_STUDENT];
		rc = fread(teachers, sizeof(teachers), 1, fp);
		if (rc != 1) {
			printf("Failed to read teachers indeces (%s)\n",
				strerror(errno));
			return -1;
		}
		
		for (int j = 0; j < NUM_OF_TEACHERS_PER_STUDENT; j++) {
			pStudent->teachers[j] = GetTeacherByIndex(teachers[j], pTeachers);
			if (pStudent->teachers[j] == NULL) {
				printf("Failed to get teacher's index");
				return -1;
			}
		}		
	}

	return 0;

}


int ReadClassrooms(FILE *fp, int records, struct ClassRoom* pRooms)
{
	unsigned char RoomIndex;
	struct ClassRoom* pRoom;

	if (records != NUM_OF_CLASSROOMS) {
		printf("Incorrect number of classrooms\n");
		return -1;
	}

	for (int i = 0; i < records; i++) {

		size_t rc = fread(&RoomIndex, sizeof(RoomIndex), 1, fp);
		if (rc != 1) {
			printf("Failed to read class name len(%s)\n",
				strerror(errno));
			return -1;
		}
		// Position onto the right room
		pRoom = &pRooms[RoomIndex];
		unsigned short nameLen = 0;
		rc = fread(&nameLen, sizeof(nameLen), 1, fp);
		if (rc != 1) {
			printf("Failed to read class name len(%s)\n",
				strerror(errno));
			return -1;
		}
		pRoom->name = malloc(nameLen + 1);
		if (!pRoom->name) {
			return -1;
		}
		memset(pRoom->name, 0x00, nameLen + 1);
		rc = fread(pRoom->name, nameLen, 1,fp);
		if (rc != 1) {
			printf("Failed to read class name (%s)\n",
				strerror(errno));
			return -1;
		}
		rc = fread(&pRoom->max_capacity, sizeof(pRoom->max_capacity), 1, fp);
		if (rc != 1) {
			printf("Failed to read class max capacity (%s)\n",
				strerror(errno));
			return -1;
		}
		SetCompressionFormat(pRoom);
	}
	return 0;
}


void ReadBinFile(const char* fileName,
	struct ClassRoom** ppRooms,
	struct Teacher** ppTeachers,
	struct Student** ppStudents)
{
	FILE* fp;

	fp = fopen(fileName, "r");
	if (!fp) {
		printf("Failed to open %s (%s)\n",
			fileName,
			strerror(errno));
		return;
	}

	unsigned char type;
	// Read rooms
	size_t rc = fread(&type, sizeof(type), 1, fp);
	if (rc != 1) {
		printf("Failed to read (%s)\n",
			strerror(errno));
		return;
	}
	if (type != TYPE_CLASSROOM) {
		printf("incorrect type. file format error\n");
		return;
	}

	signed short records;
	rc = fread(&records, sizeof(records), 1, fp);
	if (rc != 1) {
		printf("Failed to read (%s)\n",
			strerror(errno));
		return;
	}
	
	if (records != NUM_OF_CLASSROOMS) {
		printf("invalid number of room records\n");
		return;
	}

	*ppRooms = calloc(records, sizeof(struct ClassRoom));

	rc  = ReadClassrooms(fp, records, *ppRooms);
	if (rc) {
		printf("Failed to read classrooms\n");
		return;
	}
	rc = fread(&type, sizeof(type), 1, fp);
	if (rc != 1) {
		printf("Failed to read (%s)\n",
			strerror(errno));
		return;
	}

	if (type != TYPE_TEACHER) {
		printf("incorrect type. file format error\n");
		return;
	}
	
	rc = fread(&records, sizeof(records), 1, fp);
	if (rc != 1) {
		printf("Failed to read (%s)\n",
			strerror(errno));
		return;
	}
	*ppTeachers = calloc(records, sizeof(struct Teacher));
	rc = ReadTeachers(fp, records, *ppTeachers, *ppRooms);
	if (rc) {
		printf("Failed to read teachers");
		return;
	}

	rc = fread(&type, sizeof(type), 1, fp);
	if (rc != 1) {
		printf("Failed to read (%s)\n",
			strerror(errno));
		return;
	}

	if (type != TYPE_STUDENT) {
		printf("incorrect type. file format error\n");
		return;
	}
	
	rc = fread(&records, sizeof(records), 1, fp);
	if (rc != 1) {
		printf("Failed to read (%s)\n",
			strerror(errno));
		return;
	}
	*ppStudents = calloc(records, sizeof(struct Student));
	rc = ReadStudents(fp, records, *ppRooms, *ppTeachers, *ppStudents);
	if (rc) {
		printf("Failed to read students from file\n");
	}
	
}

