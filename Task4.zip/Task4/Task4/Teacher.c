

#define  _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <stdio.h>
#include "Teacher.h"
#include "Student.h"

static char* teachers_names[NUM_OF_TEACHERS] = {"ariel","efrat", "hagit","anat", "david", "liran"};


const char* GetTeacherNameByIdx(int idx)
{
	return teachers_names[idx];
}

struct Teacher* FindTeacher(const char *name, struct Teacher *teachers)
{
	struct Teacher* teacher = teachers;
	
	for (int i = 0; i < NUM_OF_TEACHERS; i++) {
		if (!strcmp(name, teacher->name)) {
			return teacher;
		}
		teacher++;
	}
	return NULL;
}

struct Teacher* GetTeacherByIndex(signed char idx, struct Teacher* pTeachers)
{
	if (idx < 0 || idx > NUM_OF_TEACHERS)
		return NULL;
	return &pTeachers[idx];
}

unsigned char GetIndexOfTeacher(struct Teacher *pTeacher, struct Teacher* pTeachers)
{
	for (int i = 0; i < NUM_OF_TEACHERS; i++) {
		struct Teacher* teacher = &pTeachers[i];
		if (!strcmp(pTeacher->name, teacher->name))
			return i;
	}
	return -1;
}

void PrintTeacher(struct Teacher* teacher)
{
	if (!teacher) {
		printf("Teacher: None\n");
		return;
	}
	printf("Teacher: %s\n", teacher->name);
	if (teacher->classroom) {
		printf("Assigned to class room %s\n", teacher->classroom->name);
	}
	else {
		printf("Not assigned to a class room\n");
	}
	
}

void PrintTeachers(struct Teacher* teachers)
{
	if (!teachers) {
		printf("No teachers\n");
		return;
	}
	for (int i = 0; i < NUM_OF_TEACHERS; i++) {
		PrintTeacher(teachers + i);
	}
}


struct Teacher* GenerateTeachers(void)
{
	struct Teacher* teachers = malloc( sizeof(struct Teacher) * NUM_OF_TEACHERS);
	if (!teachers) {
			return NULL;
	}

	struct Teacher* t = teachers;
	for (int i = 0; i < NUM_OF_TEACHERS; i++, t++) {
		t->name = malloc(strlen(teachers_names[i]) + 1);
		if (!t->name) {
			return NULL;
		}
		strcpy(t->name, teachers_names[i] );
		t->classroom = NULL;
	}

	return teachers;
}

void PrintTeachersList(struct Teacher* pTeachers)
{
	for (int i = 0; i < NUM_OF_TEACHERS; i++) {
		printf("%s ", (pTeachers + i)->name);
	}
}
